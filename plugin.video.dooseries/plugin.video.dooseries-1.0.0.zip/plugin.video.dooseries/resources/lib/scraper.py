#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2013 iClosedz (iClosedz.blogspot.com)
#	 Thanks to sphere (https://github.com/dersphere)
#	
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import urllib2,urllib,re,json
from BeautifulSoup import BeautifulSoup

usefull = {'stype': '', 'surl': '', 'poster': '', 'uagent': ''}
CATEGORIES1 = (
    {'title': 'us_series', 'path': 'show_series', 'stype': 's_us'},
	{'title': 'kr_series', 'path': 'show_series', 'stype': 's_kr'},
	{'title': 'kr_ru_series', 'path': 'show_ru_series', 'stype': 's_ru_kr'},
	{'title': 'jp_series', 'path': 'show_series', 'stype': 's_jp'},
	{'title': 'jp_ru_series', 'path': 'show_ru_series', 'stype': 's_ru_jp'},
	{'title': 'cn_series', 'path': 'show_series', 'stype': 'sc_cn'},
	{'title': 'th_series', 'path': 'show_series', 'stype': 'sc_th'},
	{'title': 'anime', 'path': 'show_series', 'stype': 's_an'},
	{'title': 'cartoons', 'path': 'show_series', 'stype': 's_ct'},
	{'title': 'movies', 'path': 'show_movies', 'stype': 'm_mo'},
	{'title': 'm_as', 'path': 'show_movies', 'stype': 'm_as'},
	{'title': 'sports', 'path': 'show_links', 'stype': 'l_sp'},
	{'title': 'kids', 'path': 'show_links', 'stype': 'l_kd'},
	{'title': 'tv', 'path': 'show_links', 'stype': 'l_tv'}
)
CATEGORIES2_1 = (
    {'title': 'latest', 'path': 'show_names', 'soption': 'latest'},
	{'title': 'orderby', 'path': 'show_names', 'soption': 'orderby'},
	{'title': 'newupdate', 'path': 'show_new_episodes', 'soption': 'newupdate'},
	{'title': 'search', 'path': 'show_search', 'soption': 'search'}
)
CATEGORIES2_2 = (
    {'title': 'orderby_az', 'path': 'show_orderby', 'soption': 'orderby_az'},
	{'title': 'orderby_genre', 'path': 'show_orderby', 'soption': 'orderby_genre'}
)

CATEGORIES3_2 = ['Action', 'Comedy', 'Crime', 'Fantasy', 'Historical', 'Medical', 'Melodrama', 'Musical', 'Mystery', 'Period', 'Romance', 'Sitcom']
CATEGORIES3_3 = (
	{'title': 'ch_3', 'cat': '0'},
	{'title': 'ch_5', 'cat': '1'},
	{'title': 'ch_7', 'cat': '2'},
	{'title': 'ch_9', 'cat': '3'},
	{'title': 'ch_etc', 'cat': '4'}
)
CATEGORIES3_4 = (
	{'title': 'cn_s', 'cat': '0'},
	{'title': 'tw_s', 'cat': '1'}
)

class NetworkError(Exception):
    pass

def get_categories1():
    return CATEGORIES1

def get_categories2_1():
    return CATEGORIES2_1
def get_categories2_2():
    return CATEGORIES2_2

def get_categories3_2():
    return CATEGORIES3_2
def get_categories3_3():
    return CATEGORIES3_3
def get_categories3_4():
    return CATEGORIES3_4

class BaseScraper(object):
	pass
	
#############################################################################	
def get_option(page, stype, soption, key):
	#for 2 version
	if stype == 's_us' or stype == 's_kr' or stype == 'm_mo' or stype == 'm_as':
		usefull = __get_usefull(stype)
		query_args = {'type':'serie', 'pid':page-1, 'ps':20}
		if soption == 'orderby':
			query_args['orderby'] = 'name'
		else:
			if soption == 'orderby_az':
				query_args['sort'] = key
			elif soption == 'orderby_genre':
				query_args['keyword'] = key	
				query_args['ps'] = 100
				query_args['SeriesType'] = 'Type'
		if stype == 's_kr':
			query_args['type'] = 'getall'
		return _get_names_new(query_args, stype)
			
	else:
		usefull = __get_usefull(stype)
		if soption == 'orderby':
			url = usefull['surl'] + '?type=serie&pid=%d&ps=20&orderby=name' % int(page-1)
		elif soption == 'orderby_ch':
			url = usefull['surl'] + '?type=serie&pid=%d&ps=20&orderby=&cat=%s' % (int(page-1), key)
		elif soption == 'orderby_ct':
			url = usefull['surl'] + '?type=serie&pid=%d&ps=20&orderby=&cat=%s' % (int(page-1), key)
		else:
			url = usefull['surl'] + '?type=serie&pid=%d&ps=20' % int(page-1)
		return _get_names(url, stype)

def get_serch_result(stype, search_string):
	#for 2 version
	if stype == 's_us' or stype == 's_kr' or stype == 'm_mo' or stype == 'm_as':
		usefull = __get_usefull(stype)
		query_args = {'type':'serie', 'pid':0, 'ps':100, 'keyword':search_string, 'SeriesType':'Name'}
		'''
		if stype == 's_kr' or stype == 'm_mo' or stype == 'm_as':
			query_args['SeriesType'] = 'Name'
			if stype == 's_kr' or stype == 'm_as':
				query_args['type'] = 'getall'
		'''
		if stype == 's_kr' or stype == 'm_as':
			query_args['type'] = 'getall'		
		#query_args = urllib.urlencode(query_args)
		return _get_names_new(query_args, stype)
	else:
		usefull = __get_usefull(stype)
		params = {'keyword': search_string}
		url = usefull['surl'] + '?type=serie&pid=0&ps=1000&%s' % urllib.urlencode(params)
		return _get_names(url, stype)

def get_movies(name_id, stype):
	usefull = __get_usefull(stype)
	query_args = { 'id':name_id, 'type':'serielink', 'ps':100 }
	json_data = __get_tree_new(query_args)
	movies = []
	for item in json_data:
		movies.append({
			'title': item['SerieName'] + " [" + item['PartName'] + "]",
			'source': item['Link']
		})
	return movies

def get_episodes(name_id, stype):
	#for 2 version
	if stype == 's_us' or stype == 's_kr' or stype == 'm_mo' or stype == 'm_as':
		usefull = __get_usefull(stype)
		query_args = { 'type':'serielink', 'ps':100, 'id':name_id}
		#query_args['id'] = name_id
		if stype == 's_kr':
			query_args['type'] = 'getlink'
		json_data = __get_tree_new(query_args)
		episodes = []
		for item in json_data:
			episodes.append({
				'title': item['SerieName'],
				'part': item['PartNumber'],
				'date': item['LastUpdated2'],
				'source': item['Link']
			})
	else:
		usefull = __get_usefull(stype)
		url = usefull['surl'] + '?type=serielink&ps=100&id=%d' % int(name_id)
		tree, html = __get_tree(url)
		pattern = re.compile("\<Link\>(?P<link>[^\<]*)\<\/Link\>\s*")
		total = re.finditer(pattern,html)
		bufferr = []
		for i in total:
			bufferr.append({'source' : i.group('link')})
		episodes = []
		for item in tree.findAll('item'):         
			episodes.append({
				'title': item.seriename.string,
				'part': item.partnumber.string,
				'date': item.lastupdated.string
			})
		count = 0
		for i in episodes:
			i.update(bufferr[count])
			count+=1
	log('_get_episodes got %d item' % len(episodes))
	return episodes

def get_new_episodes(stype):
	if stype == 's_us' or stype == 's_kr' or stype == 'm_mo' or stype == 'm_as':
		usefull = __get_usefull(stype)
		query_args = { 'type':'serienews', 'pid':0, 'ps':20, 'pid':0 }
		if stype == 's_kr' or stype == 'm_as':
			query_args['type'] = 'getnews'
		json_data = __get_tree_new(query_args)
		episodes = []
		for item in json_data:
			if str(item['Status']) == '0':
				item['Status'] = ' [Soon]'
			elif str(item['Status']) == '1':
				item['Status'] = ' [Airing]'
			elif str(item['Status']) == '2':
				item['Status'] = ' [Completed]'
			elif str(item['Status']) == '3':
				item['Status'] = ' [ON Break]'	
			episodes.append({
				'title': item['SerieTitle'],
				'part': item['PartName'],
				'thumb': usefull['poster'] + item['PictureName'],
				'date': item['DateUploaded2'],
				'source': item['Link'],
				'status': str(item['Status'])
			})

	else:
		usefull = __get_usefull(stype)
		url = usefull['surl'] + '?type=serienews&ps=20&pid=0&device=dc9ee5e129b9633f875cec2dde8b9eaee7de9c443afd4091ab77b4dbd97e7669&version=ipad'
		tree, html = __get_tree(url)
		pattern = re.compile("\<link\>(?P<link>[^\<]*)\<\/link\>\s*")
		total = re.finditer(pattern,html)
		bufferr = []
		for i in total:
			bufferr.append({'source' : i.group('link')}) 
		episodes = []
		
		for item in tree.findAll('item'):
			if item.status.string == '0':
				item.status.string = ' [Soon]'
			elif item.status.string == '1':
				item.status.string = ' [Airing]'
			elif item.status.string == '2':
				item.status.string = ' [Completed]' 
			elif item.status.string == '3':
				item.status.string = ' [ON Break]'
			episodes.append({
				'title': item.seriename.string,
				'part': item.partname.string,
				'thumb': usefull['poster'] + item.picturename.string,
				'date': item.lastupdated.string[:10],
				'status': item.status.string
			})
		count = 0
		for i in episodes:
			i.update(bufferr[count])
			count+=1
	log('_get_new_episodes got %d item' % len(episodes))
	return episodes

def get_links(stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=All&pi=0&ps=20'
	tree, html = __get_tree(url)
	patFinderImg = re.compile('DefaultImage\":\"(.*?)\"')
	patFinderUrl = re.compile('Url1\":\"(.*?)\"')
	patFinderName = re.compile('Name\":\"(.*?)\"')
	findPatImg = re.findall(patFinderImg,html)
	findPatUrl = re.findall(patFinderUrl,html)
	findPatName = re.findall(patFinderName,html)
	bufferr = []
	links = []
	img = []
	for i in findPatImg:
		if i == '':
			img.append({'thumb': 'null'})
		else:
			img.append({'thumb': usefull['poster'] + i})
	for i in findPatName:
		bufferr.append({'title': i})
	for i in findPatUrl:
		if i == '':
			links.append({'source': 'null'})
		else:
			links.append({'source': i.replace("\\", "")})
	count = 0
	for i in links:
		i.update(bufferr[count])
		count+=1
	count = 0
	for i in links:
		i.update(img[count])
		count+=1	
	return links

def _get_names(url, stype):
	tree, html = __get_tree(url)
	names = []
	for item in tree.findAll('item'):
		if item.entitle.string:
			if stype != 'm_mo':
				if item.status.string == '0':
					item.status.string = ' [Soon]'
				elif item.status.string == '1':
					item.status.string = ' [Airing]'
				elif item.status.string == '2':
					item.status.string = ' [Completed]'
				elif item.status.string == '3':
					item.status.string = ' [ON Break]'	
			else:
				item.status.string = ''
			if (item.dateshowtime.string != None) and (len(item.dateshowtime.string) > 4):
				item.dateshowtime.string = item.dateshowtime.string[-4:]
			if item.picturename.string == None:
				item.picturename.string = 'null'
		
			names.append({
				'id': item.id.string,
				'title': item.entitle.string,
				'thumb': usefull['poster'] + item.picturename.string,
				'genre': item.type.string,
				'year': item.dateshowtime.string,
				'numberofep': item.numberofpart.string,
				'director': item.director.string,
				'plot': item.abstract.string,
				'prodcom': item.productioncompany.string,
				'studio': item.stationonair.string,
				'writer': item.written.string,
				'statusname': item.status.string,
				'trailer': item.trailer.string,
				'lastupdated': item.lastupdated.string
			})
	log('_get_names got %d item' % len(names))
	return names

def _get_names_new(query_args, stype):
	json_data = __get_tree_new(query_args)
	names = []
	for item in json_data:
		if item['EnTitle']:
			if stype != 'm_mo':
				if str(item['Status']) == '0':
					item['Status'] = ' [Soon]'
				elif str(item['Status']) == '1':
					item['Status'] = ' [Airing]'
				elif str(item['Status']) == '2':
					item['Status'] = ' [Completed]'
				elif str(item['Status']) == '3':
					item['Status'] = ' [ON Break]'	
			else:
				item['Status'] = ''
			if (item['DateShowTime'] != None) and (len(item['DateShowTime']) > 4):
				item['DateShowTime'] = item['DateShowTime'][-4:]
			if item['PictureName'] == None:
				item['PictureName'] = 'null'
			
			names.append({
				'id': item['ID'],
				'title': item['EnTitle'],
				'thumb': usefull['poster'] + item['PictureName'],
				'genre': item['Type'],
				'year': item['DateShowTime'],
				'numberofep': item['NumberOfPart'],
				'director': item['Director'],
				'plot': item['Abstract'],
				'prodcom': item['ProductionCompany'],
				'studio': item['StationOnAir'],
				'writer': item['Written'],
				'statusname': item['Status'],
				'trailer': item['TrailerLink'],
				'lastupdated': item['LastUpdated2']
			})
	log('_get_names_new got %d item' % len(names))
	return names
#GET
def __get_tree(url):
	#log('__get_tree opening url: %s' % url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', usefull['uagent'])
	try:
		html = urllib2.urlopen(req).read()
	except urllib2.HTTPError, error:
		raise NetworkError('HTTPError: %s' % error)
	log('__get_tree got %d bytes' % len(html))
	tree = BeautifulSoup(html, convertEntities=BeautifulSoup.XML_ENTITIES)
	return tree, html
#POST
def __get_tree_new(query_args):
	req = urllib2.Request(usefull['surl'])
	req.add_data(urllib.urlencode(query_args))
	req.add_header('User-Agent', usefull['uagent'])
	#log('__get_tree_new opening url: %s' % usefull['surl'])
	#log('__get_tree_new use param: %s' % req.get_data())
	try:
		html = urllib2.urlopen(req).read()
	except urllib2.HTTPError, error:
		raise NetworkError('HTTPError: %s' % error)
	log('__get_tree_new got %d bytes' % len(html))
	json_data = json.loads(html)
	return json_data
	

def __get_usefull(stype):
	if stype == 's_us':
		usefull['stype'] = 's_us'
		usefull['surl'] = 'http://allnewservice.serviceseries.com/newversion/Series9Service.ashx'
		usefull['poster'] = 'http://www.series9-admin.com/poster/'
		usefull['uagent'] = 'com.nsmsoftservice.series9iphone/3.0 (unknown, iPhone OS 7.0, iPhone, Scale/2.000000)'
	elif stype == 's_kr':
		usefull['stype'] = 's_kr'
		usefull['surl'] = 'http://allnewservice.serviceseries.com/newversion/Series8Service.ashx'
		usefull['poster'] = 'http://www.series8-admin.com/poster/'
		usefull['uagent'] = 'com.nsmsoftservice.series8iphone/3.1 (unknown, iPhone OS 7.0, iPhone, Scale/2.000000)'
	elif stype == 's_jp':
		usefull['stype'] = 's_jp'
		usefull['surl'] = 'http://series7.servicedooeii.com/serie7/service.ashx'
		usefull['poster'] = 'http://www.series7-admin.com/poster/'
		usefull['uagent'] = 'Series%207%20HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 's_an':
		usefull['stype'] = 's_an'
		usefull['surl'] = 'http://anime.servicedooeii.com/anime/service.ashx'
		usefull['poster'] = 'http://www.animefc-admin.com/poster/'
		usefull['uagent'] = 'AnimeFC%20HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'sc_th':
		usefull['stype'] = 'sc_th'
		usefull['surl'] = 'http://seriesseries.servicedooeii.com/thaidrama.ashx'
		usefull['poster'] = 'http://www.series6-admin.com/poster/'
		usefull['uagent'] = 'Series%206%20HD/2.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'sc_cn':
		usefull['stype'] = 'sc_cn'
		usefull['surl'] = 'http://seriesseries.servicedooeii.com/serie5.ashx'
		usefull['poster'] = 'http://www.series5-admin.com/poster/'
		usefull['uagent'] = 'Series%205/1.1 CFNetwork/609.1.4 Darwin/13.0.0'	
	elif stype == 'm_mo':
		usefull['stype'] = 'm_mo'
		usefull['surl'] = 'http://allnewservice.serviceseries.com/newversion/moviefcService.ashx'
		usefull['poster'] = 'http://www.moviefc-admin.com/poster/'
		usefull['uagent'] = 'com.comicfcapp.moviefciphone/3.0 (unknown, iPhone OS 7.0, iPhone, Scale/2.000000)'
	elif stype == 'm_as':
		usefull['stype'] = 'm_as'
		usefull['surl'] = 'http://allnewservice.serviceseries.com/newversion/asianfcservice.ashx'
		usefull['poster'] = 'http://www.asianfc-admin.com/thum/'
		usefull['uagent'] = 'com.comicfcapp.asianfciphone/3.0 (unknown, iPhone OS 7.0, iPhone, Scale/2.000000)'
	elif stype == 'l_sp':
		usefull['stype'] = 'l_sp'
		usefull['surl'] = 'http://sportchannel.serviceseries.com/Channel.ashx'
		usefull['poster'] = 'http://sportchannel-admin.com/info/'
		usefull['uagent'] = 'Sport%20CH/1.0 CFNetwork/609.1.4 Darwin/13.0.0'
	elif stype == 'l_kd':
		usefull['stype'] = 'l_kd'
		usefull['surl'] = 'http://kidchannel.serviceseries.com/KidchannelHandler.ashx'
		usefull['poster'] = 'http://kidchannel-admin.com/info/'
		usefull['uagent'] = 'Kid%20CH/1.1 CFNetwork/609.1.4 Darwin/13.0.0'
	elif stype == 's_ct':
		usefull['stype'] = 's_ct'
		usefull['surl'] = 'http://cartoonlive.serviceseries.com/CartoonHandler.ashx'
		usefull['poster'] = 'http://www.cartoonlive-admin.com/poster/'
		usefull['uagent'] = 'CartoonLive/1.0 CFNetwork/609.1.4 Darwin/13.0.0'
	elif stype == 'l_tv':
		usefull['stype'] = 'l_tv'
		usefull['surl'] = 'http://tvch.comli.com/tv.php'
		usefull['poster'] = 'http://tvch.comli.com/poster/'
		usefull['uagent'] = 'uPlayHD-Live/1.0.0 For XBMC Power By iClosedz (th_TH)'	
	return usefull

def log(msg):
	print(u'uPlayHD log => %s Scraper: %s' % (usefull['uagent'], msg))
